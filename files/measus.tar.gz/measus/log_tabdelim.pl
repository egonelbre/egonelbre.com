sub prepfile {
    open(LOGFILE, ">measure.mlog");
    print LOGFILE "program\tfile\tpattern\ttime (s)\tavg round (s/rounds)\tdata speed (MB/s)\n";
}

sub logtofile {
    my ($fileid, $file, $patid, $pat, $progid, $prog, $iterations, $spent) = @_;
    printf LOGFILE "$progid\t$fileid\t$patid\t%.4f\t%.4f\t%.4f\n",
        $spent, ($spent/$iterations), (-s $file)*$iterations/(1024*1024*$spent);
}

sub closefile {
    close(LOGFILE);
    system("head -1 measure.mlog > measure_sort.mlog && sed 1d measure.mlog | sort >> measure_sort.mlog")
}

push(@preop, \&prepfile);
push(@logop, \&logtofile);
push(@postop,\&closefile);