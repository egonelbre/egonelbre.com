$iterations = 10; # default

@programs = (
    "grep => grep -c PAT FILE",
    "shift-or if  => ./sorif PAT FILE",
    "shift-or bit => ./sorbit PAT FILE",
);

@patterns = (
    "a",
    "aaa",
    #"aaaaaa",
    "b",
    "bbb",
    #"bbbbbb",
    #"AGATGATC",
    #"GATCCGATTT",
    #"GACCCATAGAAAG",
);

@files = (
    "a* 16MB => ../data/a16MB.txt",
    #"a* 32MB => ../data/a32MB.txt",
    #"a* 64MB => ../data/a64MB.txt",
    #"a* 128MB => ../data/a128MB.txt",
    "ACGT? 16MB => ../data/acgt16MB.txt",
    #"ACGT? 32MB => ../data/acgt32MB.txt",
    #"ACGT? 64MB => ../data/acgt64MB.txt",
    #"ACGT? 128MB => ../data/acgt128MB.txt",
    "a-Z? 16MB => ../data/aZ16MB.txt",
    #"a-Z? 32MB => ../data/aZ32MB.txt",
    #"a-Z? 64MB => ../data/aZ64MB.txt",
    #"a-Z? 128MB => ../data/aZ128MB.txt",
);