#!/usr/bin/perl

use Time::HiRes qw ( gettimeofday tv_interval);

print "Usage: ./measus.pl tests_setup [other_setup]*\n" and exit unless @ARGV >= 1 ;

$iterations = 10;
$redirect = "> /dev/null 2>&1";
@programs = ();
@patterns = ();
@files = ();

sub trim {my $s = shift; $s =~ s/^\s+//; $s =~ s/\s+$//; return $s;}

sub logtocmd {
    my ($fileid, $file, $patid, $pat, $progid, $prog, $iterations, $spent) = @_;
    print "$progid\t$prog\n";
    printf "\tTime: %.4f seconds, $nr rounds, %.4f s/round, %.2fMB/s, file: $file (%.2f MB)\n" ,
            $spent, ($spent/$iterations) , (-s $file)*$iterations/(1024*1024*$spent), ( -s $file )/(1024*1024) ;
}

@preop  = ();
@logop  = (\&logtocmd);
@postop = ();

foreach $setup(@ARGV){
    eval { require $setup };
}

sub prephash {
    my @arr=@_;
    my @ires=();
    my %res=();
    foreach $item(@arr){
        ($id, $value) = split("=>",$item,2);
        $value = $id unless $value;
        ($id, $value) = (trim($id),trim($value));
        $res{$id}=$value;
        push(@ires,"$id");
    }
   return (\@ires,\%res);
}

my ($rifiles, $rhfiles) = prephash(@files);
my @ifiles = @$rifiles;
my %hfiles = %$rhfiles;
my ($ripats , $rhpats ) = prephash(@patterns);
my @ipats = @$ripats;
my %hpats = %$rhpats;
my ($riprogs, $rhprogs) = prephash(@programs);
my @iprogs = @$riprogs;
my %hprogs = %$rhprogs;

foreach $op_ref(@preop){&$op_ref(\%hfiles, \%hpats, \%hprogs);}

my $min_time = 0.000000001;

foreach my $fileid(@ifiles) {
    my $file = $hfiles{$fileid};
    foreach my $patid(@ipats) {
        my $pat = $hpats{$patid};
        foreach my $progid(@iprogs) {
            my $prog = $hprogs{$progid};
            $prog =~ s/PAT/'$pat'/;
            $prog =~ s/FILE/'$file'/;
            my $cmd = $prog . " " . $redirect;
            my $t0 = [gettimeofday];
            for(1..$iterations) {
                system( $cmd );
            }   
            my $spent = tv_interval ($t0);
            if ($spent < $min_time) { $spent = $min_time; }
            foreach $op_ref(@logop){&$op_ref($fileid, $file, $patid, $pat, $progid, $prog, $iterations, $spent);}
        }
    }
}
foreach $op_ref(@postop){&$op_ref(\%hfiles, \%hpats, \%hprogs);}